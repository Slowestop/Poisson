
import streamlit as st
import numpy as np
from scipy.stats import poisson
import pandas as pd

st.title("축구 경기 예측기 (Poisson 모델 기반)")

st.markdown("""
**사용법**  
1. 홈팀과 원정팀의 λ 값을 입력하세요.  
2. 푸아송 분포를 기반으로 득점 예측 및 결과 확률을 제공합니다.
""")

# 입력값 받기
lambda_home = st.number_input("홈팀 λ (평균 득점)", min_value=0.0, value=1.6, step=0.1)
lambda_away = st.number_input("원정팀 λ (평균 득점)", min_value=0.0, value=1.3, step=0.1)
max_goals = st.slider("최대 골 수 예측 범위", 3, 7, 5)

# 확률 계산
home_probs = poisson.pmf(np.arange(max_goals+1), mu=lambda_home)
away_probs = poisson.pmf(np.arange(max_goals+1), mu=lambda_away)
matrix = np.outer(home_probs, away_probs)

# 표 출력
df = pd.DataFrame(matrix, index=[f"홈 {i}" for i in range(max_goals+1)],
                  columns=[f"원정 {j}" for j in range(max_goals+1)])
st.subheader("정확한 스코어 확률표")
st.dataframe(df.style.format("{:.2%}"))

# 승/무/패 확률
home_win = np.sum(np.tril(matrix, k=-1))
draw = np.sum(np.diag(matrix))
away_win = np.sum(np.triu(matrix, k=1))

st.subheader("승/무/패 확률 요약")
st.write(f"🏠 홈 승리 확률: **{home_win:.1%}**")
st.write(f"🤝 무승부 확률: **{draw:.1%}**")
st.write(f"🛫 원정 승리 확률: **{away_win:.1%}**")

# 가장 가능성 높은 스코어
max_idx = np.unravel_index(np.argmax(matrix), matrix.shape)
st.subheader("가장 가능성 높은 스코어")
st.write(f"**{max_idx[0]} - {max_idx[1]}** (확률: {matrix[max_idx]:.1%})")
